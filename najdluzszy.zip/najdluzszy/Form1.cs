﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace najdluzszy
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void macierz()
        {

            int x = 0;
            int y = 0;
            string labeltexty = textBox1.Text;
            string[] charactersy = labeltexty.Split(' ');
            string labeltextx = textBox1.Text;
            string[] charactersx = labeltextx.Split(' ');
            for(int i = 0; i < charactersx.Length; i++)
            {
                x++;
            }
            for (int i = 0; i < charactersy.Length; i++)
            {
                y++;
            }
            int[,] macierz = new int[x, y];
            MessageBox.Show(x + " " + y);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
                
        }
        private void AddCharactersToDataGridView()
        {
            string labeltext = textBox1.Text;
            string[] characters = labeltext.Split(' ');
            if(dataGridView1.Columns.Count == 0)
            {
                dataGridView1.Columns.Add("Column1", "Character");
            } 
            foreach(var character in characters)
            {
                dataGridView1.Rows.Add(character);
            }
        }

        private void AddCharactersToDataGridView2()
        {
            string labeltext = textBox1.Text;
            string[] characters = labeltext.Split(' ');
            if (dataGridView1.Columns.Count == 0)
            {
                dataGridView1.Columns.Add("Column1", " ");
            }
            foreach (var character in characters)
            {
                dataGridView1.Columns.Add("Kolumna", character);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddCharactersToDataGridView();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AddCharactersToDataGridView2();
        }
    }
}
